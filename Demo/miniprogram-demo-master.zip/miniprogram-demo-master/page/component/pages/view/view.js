Page({
  onShareAppMessage() {
    return {
      title: 'view',
      path: 'page/component/pages/view/view'
    }
  },
})
