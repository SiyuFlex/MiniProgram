# miniprogram-demo

微信小程序示例源码
> 请使用微信开发者工具或微信客户端 6.7.2 及以上版本运行。

![扫码体验](https://developers.weixin.qq.com/miniprogram/dev/image/demo.jpg?t=18091218)

![截图](https://developers.weixin.qq.com/miniprogram/dev/image/demo.png?t=18091218)
